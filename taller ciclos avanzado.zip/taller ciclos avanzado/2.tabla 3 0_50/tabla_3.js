for (let index = 0; index <= 50; index++) {
    let tabla = 3;
    let acumuladora = 0
    acumuladora = tabla * index

    console.log(tabla, "x" ,index, "=" ,acumuladora)
    
}