
let acumuladora = 0
for (let index = 1; index <= 10; index++) {
    let n = parseInt(prompt("ingrese valor"))
    
    acumuladora= acumuladora + n
}

let promedio = acumuladora /10

console.log(promedio);