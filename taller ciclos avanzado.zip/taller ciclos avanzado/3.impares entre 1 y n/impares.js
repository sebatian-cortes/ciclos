let n = parseInt(prompt("ingrese el numero hasta donde ira el conteo"))

for (let index = 0; index <= n; index++) {
    if (index % 2 != 0) {
        console.log(index)
    }
}