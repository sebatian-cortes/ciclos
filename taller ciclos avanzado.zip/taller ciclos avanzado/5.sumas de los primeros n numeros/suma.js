let n = parseInt(prompt("ingrese el numero hasta donde ira la suma"))

let acumuladora = 0
for (let index = 0; index <= n ; index++) {
 
acumuladora = acumuladora + index

}

console.log(acumuladora)