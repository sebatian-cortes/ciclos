for (let index = 0; index < 100; index++) {
    console.log(index)

}
for (let index = 100; index > 0; index--) {
    console.log(index)

}