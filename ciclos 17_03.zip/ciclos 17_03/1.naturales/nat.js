let n = parseInt(prompt("ingrese el valor hasta donde llegara el conteo"));

let contador = 1;
while (contador <= n) {
    console.log(contador)
    contador++
}