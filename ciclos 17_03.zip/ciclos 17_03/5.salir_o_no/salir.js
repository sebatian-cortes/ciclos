let respuesta = prompt("desea salir? S/N")

while (respuesta != "S") {
    respuesta = prompt("desea salir? S/N")
}