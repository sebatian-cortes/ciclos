let n = parseInt(prompt("ingrese hasta donde ira el conteo"));

let contador = 1;
while (contador <= n) {
    if (contador % 2 !=0) {
       console.log(contador)
    }
    
    contador++
}