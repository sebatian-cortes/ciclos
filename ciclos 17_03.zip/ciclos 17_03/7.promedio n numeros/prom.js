let n = parseInt(prompt("ingrese cuantos numeros quiere promediar"))

let contador = 1;
let acumuladora = 0;

while (contador <= n) {
    
    let num = parseFloat(prompt("ingrese un valor"));
    acumuladora = acumuladora + num;
    
    contador++
   
}

let prom = acumuladora / n;
console.log("el promedio de esos 10 numeros es de:" , prom)