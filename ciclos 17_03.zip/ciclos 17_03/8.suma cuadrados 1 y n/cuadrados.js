let num = parseFloat(prompt("Ingrese hasta que número quiere sumar"))
let contador = 1;
let acumulador = 0;

while (contador <= num) {
    acumulador = acumuladora + (contador**2)
    contador++;
}

console.log("La suma de los cuadrados de los números es:",acumuladora)