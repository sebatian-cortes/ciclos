let tabla = 10;

contador = 1;
while (contador <= 50) {
    resultado = tabla * contador;
    console.log(tabla, "x", contador, "=", resultado)

    contador++
}