let n = parseInt(prompt("ingrese el valor hasta donde llegara la suma"));

let contador = 1;
let acumuladora = 0;

while (contador <= n) {
    acumuladora = acumuladora + contador
    contador++
}

console.log("la suma final es de:",acumuladora)