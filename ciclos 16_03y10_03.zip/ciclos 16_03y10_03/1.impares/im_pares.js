let num = 0
let acumuladora = 0


while (num <= 100) {
    if (num%2 !=0){
        acumuladora = acumuladora + 1
    }
    num++
}

console.log(acumuladora)



