let num = 0
let num2 = 3


while (num <= 50) {
    if (num % 3 == 0) {
        console.log(num2 * num)
    }
        
    num = num + 1
    
}

