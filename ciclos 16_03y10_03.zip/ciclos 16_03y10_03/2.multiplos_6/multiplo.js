let num = 0
let num2 = 0


while (num <= 100) {
    if (num%6 ==0){
        num2 = num2 + 1
    }
    num = num + 1
}

console.log(num2)