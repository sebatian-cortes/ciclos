let num = 0


while (num <= 100) {
    if (num%2 !=0){
        console.log(num)
    }
   num++
}

